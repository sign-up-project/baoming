class CreateImg {

  constructor(imgSrc,data,config = {width: '480', height: '600'}) {
    this.imgSrc = imgSrc;
    this.data = data;
    this.config = config;
    this.src = '';
  }

  // 初始化
  init() {
    document.body.appendChild(this.createCanvas());
setTimeout(() => {
  var src = this.canvasToImage();
  var img = document.createElement('img');
  img.src = src;
  document.body.appendChild(img);
}, 1000);
  }

  // 创建canvas对象
  createCanvas() {
    let canvas = document.createElement("canvas");
    canvas.id = 'mycanvas';
    canvas.width = this.config.width;
    canvas.height = this.config.height;
    const ctx = canvas.getContext('2d');

    //填充背景；
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, this.config.width, this.config.height);
    // ctx.fillRect(1, 1, this.config.width-2, this.config.height-2);
    ctx.fillStyle = '#000';
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(this.config.width, 0);
    
    ctx.lineTo(this.config.width,this.config.height);
    ctx.lineTo(0, this.config.height);
    ctx.lineTo(0 , 0)
    ctx.closePath();
    ctx.stroke();
  

    this.drawSchoolname(ctx);

    this.drawTitle(ctx, '考生姓名 ：', 30, 190);
    this.drawVal(ctx, 'XXX', 200, 190, 140);
    this.drawLine(ctx, 130, 196, 140);

    this.drawTitle(ctx, '报考专业 ：', 30, 250);
    this.drawVal(ctx, 'XXX', 200, 250, 140);
    this.drawLine(ctx, 130, 256, 140);

    this.drawTitle(ctx, '考生考号 ：', 30, 300);
    this.drawVal(ctx, 'XXX', 200, 300, 140);
    this.drawLine(ctx, 130, 306, 140);
    
    this.drawImg(ctx);

    return canvas;
  }

  //画 学校名称
  drawSchoolname(ctx) {
    ctx.fillStyle = '#000';
    ctx.font = "500 32px Arial";
    ctx.textAlign = 'center';
    ctx.fillText('厦门翔安艺术学校',this.config.width / 2, 80, this.config.width);
    ctx.font = "bold 21px Arial";
    ctx.fillText('准考证', this.config.width / 2, 120,this.config.width);
  }

  //画 标题
  drawTitle(ctx, name, x=30, y) {
    ctx.font = "600 18px Arial";
    ctx.textAlign = 'left';
    ctx.fillText(name, x, y, 90);
  }

  //画 对应值
  drawVal(ctx, name, x=30, y, maxWidth) {
    ctx.font = "16px Arial";
    ctx.textAlign = 'center';
    ctx.fillText(name, x, y, maxWidth);
  }

  //画 线；
  drawLine(ctx, x, y, len) {
    ctx.beginPath();
    ctx.moveTo( x, y);
    ctx.lineTo( x + len, y);
    ctx.closePath();
    ctx.stroke();
  }
  // 画照片；
  drawImg(ctx) {
    // return new Promise((resolve, reject) => {
    //   let img = new Image();
    //   console.log(123,img);
    //   img.src = this.imgSrc;
    //   img.onload = function(){
    //     ctx.drawImage(img, 290, 160, 121, 160);
    //     resolve();
    //   }
    //   img.error = function(err) {
    //     reject(err);
    //   };
    // })
    let img = new Image();
      console.log(123,img);
      img.src = this.imgSrc;
      img.onload = function(){
        ctx.drawImage(img, 290, 160, 121, 160);
      }
 
  }

  // 生成图片；
  canvasToImage() {
    let canvas = document.getElementById('mycanvas');
    console.log(canvas);
    let image = canvas.toDataURL("image/jpeg");
    return image;
  }

}